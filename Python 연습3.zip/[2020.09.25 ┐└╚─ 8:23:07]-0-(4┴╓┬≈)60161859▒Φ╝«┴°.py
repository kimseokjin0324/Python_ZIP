import numpy as np

def main():
    
    Score=np.random.randint(100,size=(10,4))
    first(Score)
    second(Score)
    third(Score)
    
def first(Score):
    result=np.where(Score>=90,'A',np.where(Score>=80,'B',np.where(Score>=70,'C','D')))
    print(result)
    
def second(Score):
    Score.mean(axis=0)
    print(Score-Score.mean(axis=0))  

  
def fourth(Score,total,Score1):
    avg=Score.mean(axis=0)#각과목 평균
    all_total=total.sum(axis=0)#총합
    avg1 = Score.mean(axis=1)#각학생 평균
    avg_total=avg1.mean(axis=0)#총평균 
    avg1=avg1.reshape(10,1)
    Score=np.hstack((Score1,avg1))
    all=np.hstack((avg,all_total,avg_total))
    Score=np.vstack((Score,all))
    print(Score)
    
def third(Score):
    total=Score.sum(axis=1)
    total=total.reshape(10,1)
    Score1=np.concatenate([Score,total],axis=1)
    print(Score1)
    fourth(Score,total,Score1)  

main()   