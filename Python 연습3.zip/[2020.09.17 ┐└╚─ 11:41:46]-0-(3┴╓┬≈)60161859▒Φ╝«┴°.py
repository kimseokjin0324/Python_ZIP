import numpy as np
Score=np.random.randint(100,size=(10,4))

def main():
    print(Score)
    math_grade()
    all_grade()
    bool_index()
    change()
    
def math_grade():#1번문제
    print("모든 학생의 수학점수만을 출력하시오 \n")
    print(Score[:,2:3])
    
def all_grade():#2
    print("각 학생의 총 합 점수를 구하시오 \n")
    i=0
    while i<10:
        print("%d번째 총 합 점수는 %s이다" %(i,sum(Score[i])))
        i+=1
        
def bool_index():#3
    print("불린인덱스를 이용하여 1,5,7,9,10번째의 학생의 과목만 출력하시오\n")
    bol_ind=np.array([0,1,2,3,4,5,6,7,8,9])
    num=(bol_ind==0)|(bol_ind==4)|(bol_ind==6)|(bol_ind==8)|(bol_ind==9)
    print(Score[num])

def change():#4
    print("10x4의 행렬을 4x10으로 변경하여 행이 과목을 열이 학생을 의마하도록 수정하여라 \n")
    print(Score.transpose((1,0)))

main()