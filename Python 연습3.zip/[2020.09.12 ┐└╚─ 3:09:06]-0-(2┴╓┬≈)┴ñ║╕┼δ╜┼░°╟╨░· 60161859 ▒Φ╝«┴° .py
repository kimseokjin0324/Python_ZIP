#60161859 정보통신공학과 김석진 
import random

def main():
    
    concantenate_list()
    
    
    for i in range(0,8):
        print(i,"번 학생의 정답 문항의 개수는",calculateGrade(i),"입니다.")
    
    
def concantenate_list():#1번문제
    LST1=[random.randint(1,100) for i in range(20)]
    LST2=[random.randint(1,100) for i in range(20)]
    LST=LST1+LST2
    set_lst=set(LST)
    print(set_lst)
    
def calculateGrade(n):#2번문제
    
    student_answer=[['A','B','A','C','C','D','E','E','A','D'],
                    ['D','B','A','B','C','A','E','E','A','D'],
                    ['E','D','D','A','C','B','E','E','A','D'],
                    ['C','B','A','E','D','C','E','E','A','D'],
                    ['A','B','D','C','C','D','E','E','A','D'],
                    ['B','B','E','C','C','D','E','E','A','D'],
                    ['B','B','A','C','C','D','E','E','A','D'],
                    ['E','B','E','C','C','D','E','E','A','D']]
    
    answer=[[0,1,2,3,4,5,6,7,8,9],['D','B','D','C','C','D','A','E','A','D']]
    answer_num=0
    num=0
    
    for x in student_answer[n]:
        if(x==answer[1][num]):
            answer_num=answer_num+1
        num=num+1
    return answer_num    
  

main()
    